package edu.co.icesi.clases2eco;

public interface Paintable {

    void paint(String a, String b, String c);
    void delete();

}
